 var sheng = [    
    {name:'全国'}, 
    {name:'河北'},
    {name:'山东'},
    {name:'辽宁'},
    {name:'黑龙江'},
    {name:'甘肃'},
    {name:'吉林'},
    {name:'青海'},
    {name:'河南'},
    {name:'江苏'},
    {name:'湖北'},
    {name:'湖南'},
    {name:'浙江'},
    {name:'江西'},
    {name:'广东'},
    {name:'云南'},
    {name:'福建'},
    {name:'山西'},
    {name:'四川'},
    {name:'陕西'},
    {name:'贵州'},
    {name:'安徽'},
    {name:'内蒙古'},
    {name:'广西'},
   
 ]


 var category =   
        
            {
                '大豆':'bigBean',
                '玉米':'corn',
                '棉花':'cotton',
                '早稻':'doubleEarly',
                '晚稻':'doubleLate',
                '油菜':'oilVeggie',
                '一季稻':'OneSeason',
                '冬小麦':'winterSmall'
            }
        
  

export {sheng,category}