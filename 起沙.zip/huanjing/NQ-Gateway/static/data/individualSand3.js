export default [
    {date:20150221,type:'扬沙',rate:9.7},
    {date:20150302,type:'扬沙',rate:9.7},
    {date:20150308,type:'扬沙',rate:9.7},
    {date:20150314,type:'扬沙',rate:9.7},
   

]