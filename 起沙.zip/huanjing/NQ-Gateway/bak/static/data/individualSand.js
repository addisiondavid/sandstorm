export default [
    {date:20150221000000,type:'扬沙',rate:897,affect:'内蒙古,陕西',generalIndx:4.5,areaIndx:2.9,strongIndx:1.48,durationIndx:1.13},
    {date:20150302000000,type:'沙尘',rate:987,affect:'新疆',generalIndx:1.12,areaIndx:1.28,strongIndx:1.35,durationIndx:0.65},
    {date:20150308000000,type:'扬沙',rate:896,affect:'内蒙古,陕西',generalIndx:0.95,areaIndx:0.96,strongIndx:1.43,durationIndx:0.69},
    {date:20150314000000,type:'沙尘暴',rate:897,affect:'新疆',generalIndx:1.5,areaIndx:1.84,strongIndx:1.25,durationIndx:0.65},
    {date:20150327000000,type:'扬沙',rate:896,affect:'山西',generalIndx:5.4,areaIndx:2.77,strongIndx:1.16,durationIndx:1.68},
    {date:20150331000000,type:'沙尘暴',rate:847,affect:'浙江,上海,江苏',generalIndx:12.78,areaIndx:6.71,strongIndx:1.78,durationIndx:1.07},
    {date:20150415000000,type:'沙尘',rate:894,affect:'内蒙古,陕西',generalIndx:18.97,areaIndx:6.96,strongIndx:1.77,durationIndx:1.54},
    {date:20150427000000,type:'扬沙',rate:882,affect:'内蒙古,陕西',generalIndx:1.4,areaIndx:1.82,strongIndx:1.3,durationIndx:0.59},
    {date:20150430000000,type:'扬沙',rate:897,affect:'内蒙古,陕西',generalIndx:1.61,areaIndx:1.66,strongIndx:1.67,durationIndx:0.58},
    {date:20150505000000,type:'扬沙',rate:897,affect:'内蒙古,陕西',generalIndx:1.05,areaIndx:1.37,strongIndx:1.39,durationIndx:0.55},
    {date:20150531000000,type:'扬沙',rate:851,affect:'内蒙古,陕西',generalIndx:2.25,areaIndx:2.61,strongIndx:1.51,durationIndx:0.57},
    {date:20150815000000,type:'沙尘',rate:877,affect:'内蒙古,宁夏',generalIndx:1.38,areaIndx:1.48,strongIndx:1.66,durationIndx:0.56},

]