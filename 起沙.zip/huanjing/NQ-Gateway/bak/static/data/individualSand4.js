export default [
    {date:20150221,type:'扬沙',rate:9.7},
    {date:20150302,type:'扬沙',rate:9.7},
    {date:20150308,type:'扬沙',rate:9.7},
    {date:20150314,type:'扬沙',rate:9.7},
    {date:20150327,type:'扬沙',rate:9.7},
    {date:20150331,type:'扬沙',rate:9.7},
    {date:20150401,type:'扬沙',rate:9.7},
    {date:20150415,type:'扬沙',rate:9.7},
    {date:20150427,type:'扬沙',rate:9.7},
    {date:20150429,type:'扬沙',rate:9.7},
    {date:20150430,type:'扬沙',rate:9.7},
    {date:20150505,type:'扬沙',rate:9.7},
    {date:20150429,type:'扬沙',rate:9.7},
    {date:20150430,type:'扬沙',rate:9.7},
    {date:20150505,type:'扬沙',rate:9.7},

]