const actions = {
    // updatedUser(context, user) {
    //     context.commit('updatedUser', user);
    // }

    updateNoticeData(context, payload) {
        context.commit('updateNoticeData', payload);
    }
}

export default actions;
