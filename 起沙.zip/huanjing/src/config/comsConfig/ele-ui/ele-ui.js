import 'element-ui/lib/theme-chalk/index.css'
// 引入element form相关组件
import './el-form';
// 引入element 日期选择组件
import './el-datePicker';
