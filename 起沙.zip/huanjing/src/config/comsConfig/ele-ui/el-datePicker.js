import Vue from 'vue';
import {
    DatePicker,
    TimeSelect,
    TimePicker
} from 'element-ui';

Vue.use(DatePicker);
Vue.use(TimeSelect);
Vue.use(TimePicker);
